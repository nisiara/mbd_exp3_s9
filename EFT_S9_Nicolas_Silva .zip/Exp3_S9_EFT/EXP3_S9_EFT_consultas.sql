
-- Encontrar todas las academias de danza
SELECT id_academia, nombre, telefono, email
FROM academia
WHERE tipo = 'D';

-- Listar los cursos con cupo mayor a 12 estudiantes
SELECT id_curso, nombre, duracion_hrs, cupo
FROM curso
WHERE cupo > 12
ORDER BY cupo DESC;

-- Encontrar profesores que son de planta (tiempo completo)
SELECT id_profesor, nombre, apellido_paterno, apellido_materno
FROM profesor
WHERE tipo_profesor = 'P';

-- Mostrar los programas (fondos concursables) con montos mayores a 5 millones
SELECT id_programa, nombre, monto, limite_postulacion
FROM programa
WHERE monto > 5000000
ORDER BY monto DESC;
