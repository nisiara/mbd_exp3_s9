-- REGION
INSERT INTO region (id_region, nombre) VALUES
('R01', 'Región Metropolitana de Santiago');
INSERT INTO region (id_region, nombre) VALUES
('R02', 'Región de Valparaíso');
INSERT INTO region (id_region, nombre) VALUES
('R03', 'Región del Biobío');
INSERT INTO region (id_region, nombre) VALUES
('R04', 'Región de La Araucanía');
INSERT INTO region (id_region, nombre) VALUES
('R05', 'Región de Coquimbo');

-- BANCO
INSERT INTO banco (id_banco, nombre) VALUES
('B001', 'Banco Estado');
INSERT INTO banco (id_banco, nombre) VALUES
('B002', 'Banco Santander');
INSERT INTO banco (id_banco, nombre) VALUES
('B003', 'Banco BCI');
INSERT INTO banco (id_banco, nombre) VALUES
('B004', 'Banco Chile');
INSERT INTO banco (id_banco, nombre) VALUES
('B005', 'Banco Scotiabank');

-- TURNO
INSERT INTO turno (id_turno, tipo_turno) VALUES
('T001', 'D');
INSERT INTO turno (id_turno, tipo_turno) VALUES
('T002', 'D');
INSERT INTO turno (id_turno, tipo_turno) VALUES
('T003', 'V');
INSERT INTO turno (id_turno, tipo_turno) VALUES
('T004', 'V');
INSERT INTO turno (id_turno, tipo_turno) VALUES
('T005', 'D');

ALTER TABLE comuna MODIFY municipalidad_id_muni CHAR(5 BYTE) NULL;

INSERT INTO comuna (id_comuna, nombre, region_id_region, municipalidad_id_muni) VALUES
('C001', 'Santiago', 'R01', NULL);

INSERT INTO comuna (id_comuna, nombre, region_id_region, municipalidad_id_muni) VALUES
('C002', 'Viña del Mar', 'R02', NULL);

INSERT INTO comuna (id_comuna, nombre, region_id_region, municipalidad_id_muni) VALUES
('C003', 'Concepción', 'R03', NULL);

INSERT INTO comuna (id_comuna, nombre, region_id_region, municipalidad_id_muni) VALUES
('C004', 'Temuco', 'R04', NULL);

INSERT INTO comuna (id_comuna, nombre, region_id_region, municipalidad_id_muni) VALUES
('C005', 'La Serena', 'R05', NULL);


--MUNICIPALIDADES
INSERT INTO municipalidad (id_muni, nombre, comuna_id_comuna) VALUES
('M001', 'I.M de Santiago', 'C001');

INSERT INTO municipalidad (id_muni, nombre, comuna_id_comuna) VALUES
('M002', 'I.M de Viña del Mar', 'C002');

INSERT INTO municipalidad (id_muni, nombre, comuna_id_comuna) VALUES
('M003', 'I.M de Concepción', 'C003');

INSERT INTO municipalidad (id_muni, nombre, comuna_id_comuna) VALUES
('M004', 'I.M de Temuco', 'C004');

INSERT INTO municipalidad (id_muni, nombre, comuna_id_comuna) VALUES
('M005', 'I.M de La Serena', 'C005');

UPDATE comuna SET municipalidad_id_muni = 'M001' WHERE id_comuna = 'C001';
UPDATE comuna SET municipalidad_id_muni = 'M002' WHERE id_comuna = 'C002';
UPDATE comuna SET municipalidad_id_muni = 'M003' WHERE id_comuna = 'C003';
UPDATE comuna SET municipalidad_id_muni = 'M004' WHERE id_comuna = 'C004';
UPDATE comuna SET municipalidad_id_muni = 'M005' WHERE id_comuna = 'C005';


ALTER TABLE comuna MODIFY municipalidad_id_muni CHAR(5 BYTE) NOT NULL;

-- ESPACIO
INSERT INTO espacio (id_espacio, municipalidad_id_muni, nombre) VALUES
('E001', 'M001', 'Teatro Municipal');
INSERT INTO espacio (id_espacio, municipalidad_id_muni, nombre) VALUES
('E002', 'M002', 'Quinta Vergara');
INSERT INTO espacio (id_espacio, municipalidad_id_muni, nombre) VALUES
('E003', 'M003', 'Casa de la Cultura');
INSERT INTO espacio (id_espacio, municipalidad_id_muni, nombre) VALUES
('E004', 'M004', 'Centro Cultural Municipal');
INSERT INTO espacio (id_espacio, municipalidad_id_muni, nombre) VALUES
('E005', 'M005', 'Salón Canto Municipal');

-- PROFESOR
INSERT INTO profesor (id_profesor, rut, digito_verificador, nombre, apellido_paterno, apellido_materno, tipo_profesor) VALUES
('P001', 12345678, '1', 'Juan', 'González', 'Pérez', 'P');
INSERT INTO profesor (id_profesor, rut, digito_verificador, nombre, apellido_paterno, apellido_materno, tipo_profesor) VALUES
('P002', 23456789, '2', 'María', 'Sánchez', 'López', 'H');
INSERT INTO profesor (id_profesor, rut, digito_verificador, nombre, apellido_paterno, apellido_materno, tipo_profesor) VALUES
('P003', 34567890, '3', 'Carlos', 'Rodríguez', 'Gómez', 'P');
INSERT INTO profesor (id_profesor, rut, digito_verificador, nombre, apellido_paterno, apellido_materno, tipo_profesor) VALUES
('P004', 45678901, '4', 'Ana', 'Martínez', 'Silva', 'H');
INSERT INTO profesor (id_profesor, rut, digito_verificador, nombre, apellido_paterno, apellido_materno, tipo_profesor) VALUES
('P005', 56789012, '5', 'Pedro', 'Fernández', 'Díaz', 'P');

-- PROF_PLANTA
INSERT INTO prof_planta (id_profesor, sueldo_base, dias_vacaciones) VALUES
('P001', 800000, 15);
INSERT INTO prof_planta (id_profesor, sueldo_base, dias_vacaciones) VALUES
('P003', 850000, 15);
INSERT INTO prof_planta (id_profesor, sueldo_base, dias_vacaciones) VALUES
('P005', 820000, 15);

-- PROF_HONORARIO
INSERT INTO prof_honorario (id_profesor, tarifa_hora, cantidad_hrs) VALUES
('P002', 15000, 20);
INSERT INTO prof_honorario (id_profesor, tarifa_hora, cantidad_hrs) VALUES
('P004', 18000, 15);


ALTER TABLE academia MODIFY director_id_director CHAR(5 BYTE) NULL;


INSERT INTO academia (id_academia, nombre, tipo, rut, digito_verificador, telefono, email, direccion, numero_dir, comuna_id_comuna, director_id_director)
VALUES ('A001', 'Escuela de Danza Moderna', 'D', 11111112, '2', 912345678, 'contacto@danzamoderna.cl', 'Av. Principal', 123, 'C001', NULL);

INSERT INTO academia (id_academia, nombre, tipo, rut, digito_verificador, telefono, email, direccion, numero_dir, comuna_id_comuna, director_id_director)
VALUES ('A002', 'Conservatorio Musical', 'I', 22222223, '3', 923456789, 'info@conservatorio.cl', 'Calle Música', 456, 'C002', NULL);

INSERT INTO academia (id_academia, nombre, tipo, rut, digito_verificador, telefono, email, direccion, numero_dir, comuna_id_comuna, director_id_director)
VALUES ('A003', 'Academia de Canto', 'C', 33333334, '4', 934567890, 'contacto@academiacanto.cl', 'Pasaje Lírico', 789, 'C003', NULL);


INSERT INTO director (id_director, nombre, apellido_paterno, apellido_materno, rut, digito_verificador, academia_id_academia)
VALUES ('D001', 'Roberto', 'García', 'Luna', 11111111, '1', 'A001');

INSERT INTO director (id_director, nombre, apellido_paterno, apellido_materno, rut, digito_verificador, academia_id_academia)
VALUES ('D002', 'Carmen', 'López', 'Soto', 22222222, '2', 'A002');

INSERT INTO director (id_director, nombre, apellido_paterno, apellido_materno, rut, digito_verificador, academia_id_academia)
VALUES ('D003', 'Felipe', 'Torres', 'Rojas', 33333333, '3', 'A003');


UPDATE academia SET director_id_director = 'D001' WHERE id_academia = 'A001';
UPDATE academia SET director_id_director = 'D002' WHERE id_academia = 'A002';
UPDATE academia SET director_id_director = 'D003' WHERE id_academia = 'A003';


ALTER TABLE academia MODIFY director_id_director CHAR(5 BYTE) NOT NULL;

-- CUENTA
INSERT INTO cuenta (nombre_banco, tipo_cuenta, numero_cuenta, nombre_titular, a_paterno_titular, academia_id_academia, banco_id_banco) VALUES
('Banco Estado', 'C', 123456789012345, 'Roberto', 'García', 'A001', 'B001');
INSERT INTO cuenta (nombre_banco, tipo_cuenta, numero_cuenta, nombre_titular, a_paterno_titular, academia_id_academia, banco_id_banco) VALUES
('Banco Santander', 'A', 234567890123456, 'Carmen', 'López', 'A002', 'B002');
INSERT INTO cuenta (nombre_banco, tipo_cuenta, numero_cuenta, nombre_titular, a_paterno_titular, academia_id_academia, banco_id_banco) VALUES
('Banco BCI', 'V', 345678901234567, 'Felipe', 'Torres', 'A003', 'B003');

-- CONTRATO
INSERT INTO contrato (profesor_id_profesor, academia_id_academia, tipo, fecha_inicio, estado) VALUES
('P001', 'A001', 'D', TO_DATE('2023-01-01', 'YYYY-MM-DD'), 'A');
INSERT INTO contrato (profesor_id_profesor, academia_id_academia, tipo, fecha_inicio, estado) VALUES
('P002', 'A002', 'V', TO_DATE('2023-02-01', 'YYYY-MM-DD'), 'A');
INSERT INTO contrato (profesor_id_profesor, academia_id_academia, tipo, fecha_inicio, estado) VALUES
('P003', 'A003', 'D', TO_DATE('2023-03-01', 'YYYY-MM-DD'), 'A');
INSERT INTO contrato (profesor_id_profesor, academia_id_academia, tipo, fecha_inicio, estado) VALUES
('P004', 'A001', 'V', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 'A');
INSERT INTO contrato (profesor_id_profesor, academia_id_academia, tipo, fecha_inicio, estado) VALUES
('P005', 'A002', 'D', TO_DATE('2023-05-01', 'YYYY-MM-DD'), 'A');

-- PROGRAMA
INSERT INTO programa (id_programa, monto, nombre, limite_postulacion) VALUES
('PR001', 5000000, 'Fondart Regional', TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO programa (id_programa, monto, nombre, limite_postulacion) VALUES
('PR002', 8000000, 'Fondo de la Música', TO_DATE('2024-07-31', 'YYYY-MM-DD'));
INSERT INTO programa (id_programa, monto, nombre, limite_postulacion) VALUES
('PR003', 6000000, 'Fondo Escuelas de Rock', TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO programa (id_programa, monto, nombre, limite_postulacion) VALUES
('PR004', 7000000, 'Chile Creativo', TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO programa (id_programa, monto, nombre, limite_postulacion) VALUES
('PR005', 4000000, 'Fondo Desarrollo Cultural', TO_DATE('2024-10-31', 'YYYY-MM-DD'));

-- POSTULACION
INSERT INTO postulacion (academia_id_academia, programa_id_programa, fecha, cod_postulacion) VALUES
('A001', 'PR001', TO_DATE('2024-01-15', 'YYYY-MM-DD'), 'PS001');
INSERT INTO postulacion (academia_id_academia, programa_id_programa, fecha, cod_postulacion) VALUES
('A002', 'PR002', TO_DATE('2024-02-15', 'YYYY-MM-DD'), 'PS002');
INSERT INTO postulacion (academia_id_academia, programa_id_programa, fecha, cod_postulacion) VALUES
('A003', 'PR003', TO_DATE('2024-03-15', 'YYYY-MM-DD'), 'PS003');

ALTER TABLE curso MODIFY duracion_hrs NUMBER(4,2);
-- CURSO
INSERT INTO curso (id_curso, nombre, duracion_hrs, academia_id_academia, profesor_id_profesor, cupo, espacio_id_espacio) VALUES
('C001', 'Danza Contemporánea', 40.5, 'A001', 'P001', 15, 'E001');
INSERT INTO curso (id_curso, nombre, duracion_hrs, academia_id_academia, profesor_id_profesor, cupo, espacio_id_espacio) VALUES
('C002', 'Piano Avanzado', 30.0, 'A002', 'P002', 10, 'E002');
INSERT INTO curso (id_curso, nombre, duracion_hrs, academia_id_academia, profesor_id_profesor, cupo, espacio_id_espacio) VALUES
('C003', 'Técnica Vocal', 25.5, 'A003', 'P003', 12, 'E003');
INSERT INTO curso (id_curso, nombre, duracion_hrs, academia_id_academia, profesor_id_profesor, cupo, espacio_id_espacio) VALUES
('C004', 'Ballet Clásico', 35.0, 'A001', 'P004', 20, 'E004');
INSERT INTO curso (id_curso, nombre, duracion_hrs, academia_id_academia, profesor_id_profesor, cupo, espacio_id_espacio) VALUES
('C005', 'Violín Principiantes', 28.5, 'A002', 'P005', 8, 'E005');

-- HORARIO
INSERT INTO horario (curso_id_curso, turno_id_turno, horario_inicio, horario_fin) VALUES
('C001', 'T001', TO_DATE('2024-01-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-01-01 11:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO horario (curso_id_curso, turno_id_turno, horario_inicio, horario_fin) VALUES
('C002', 'T002', TO_DATE('2024-01-01 11:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-01-01 13:30:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO horario (curso_id_curso, turno_id_turno, horario_inicio, horario_fin) VALUES
('C003', 'T003', TO_DATE('2024-01-01 15:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO horario (curso_id_curso, turno_id_turno, horario_inicio, horario_fin) VALUES
('C004', 'T004', TO_DATE('2024-01-01 17:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-01-01 19:30:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO horario (curso_id_curso, turno_id_turno, horario_inicio, horario_fin) VALUES
('C005', 'T005', TO_DATE('2024-01-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-01-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'));
