
CREATE TABLE academia (
    id_academia          CHAR(5 BYTE) NOT NULL,
    nombre               VARCHAR2(25 BYTE) NOT NULL,
    tipo                 CHAR(1 BYTE) NOT NULL,
    rut                  NUMBER(8) NOT NULL,
    digito_verificador   CHAR(1 BYTE) NOT NULL,
    telefono             NUMBER(9) NOT NULL,
    email                VARCHAR2(40 BYTE) NOT NULL,
    direccion            VARCHAR2(30 BYTE) NOT NULL,
    numero_dir           NUMBER(4) NOT NULL,
    comuna_id_comuna     CHAR(5 BYTE) NOT NULL,
    director_id_director CHAR(5 BYTE) NOT NULL
);

ALTER TABLE academia
    ADD CONSTRAINT restriccion_tipo CHECK ( tipo IN ( 'C', 'D', 'I' ) );

ALTER TABLE academia
    ADD CONSTRAINT validacion_rut CHECK ( digito_verificador IN ( '0', '1', '2', '3', '4',
                                                                  '5', '6', '7', '8', '9',
                                                                  'K' ) );

CREATE UNIQUE INDEX academia__idx ON
    academia (
        director_id_director
    ASC );

ALTER TABLE academia ADD CONSTRAINT academia_pk PRIMARY KEY ( id_academia );

ALTER TABLE academia ADD CONSTRAINT academia_rut_un UNIQUE ( rut );

CREATE TABLE banco (
    id_banco CHAR(5 BYTE) NOT NULL,
    nombre   VARCHAR2(25 BYTE) NOT NULL
);

ALTER TABLE banco ADD CONSTRAINT banco_pk PRIMARY KEY ( id_banco );

CREATE TABLE comuna (
    id_comuna             CHAR(5 BYTE) NOT NULL,
    nombre                VARCHAR2(25 BYTE) NOT NULL,
    region_id_region      CHAR(5 BYTE) NOT NULL,
    municipalidad_id_muni CHAR(5 BYTE) NOT NULL
);

CREATE UNIQUE INDEX comuna__idx ON
    comuna (
        municipalidad_id_muni
    ASC );

ALTER TABLE comuna ADD CONSTRAINT comuna_pk PRIMARY KEY ( id_comuna );

CREATE TABLE contrato (
    profesor_id_profesor CHAR(5 BYTE) NOT NULL,
    academia_id_academia CHAR(5 BYTE) NOT NULL,
    tipo                 CHAR(1 BYTE) NOT NULL,
    fecha_inicio         DATE NOT NULL,
    estado               CHAR(1 BYTE) NOT NULL
);

ALTER TABLE contrato
    ADD CHECK ( tipo IN ( 'D', 'V' ) );

ALTER TABLE contrato
    ADD CONSTRAINT restriccion_estado CHECK ( estado IN ( 'A', 'I' ) );

ALTER TABLE contrato ADD CONSTRAINT contrato_pk PRIMARY KEY ( profesor_id_profesor,
                                                              academia_id_academia );

CREATE TABLE cuenta (
    nombre_banco         VARCHAR2(25 BYTE) NOT NULL,
    tipo_cuenta          CHAR(1 BYTE) NOT NULL,
    numero_cuenta        NUMBER(15) NOT NULL,
    nombre_titular       VARCHAR2(25 BYTE) NOT NULL,
    a_paterno_titular    VARCHAR2(25 BYTE) NOT NULL,
    a_materno_titular    VARCHAR2(25 BYTE),
    academia_id_academia CHAR(5 BYTE) NOT NULL,
    banco_id_banco       CHAR(5 BYTE) NOT NULL
);

ALTER TABLE cuenta
    ADD CONSTRAINT restriccion_cuenta CHECK ( tipo_cuenta IN ( 'A', 'C', 'V' ) );

CREATE TABLE curso (
    id_curso             CHAR(5 BYTE) NOT NULL,
    nombre               VARCHAR2(25 BYTE) NOT NULL,
    duracion_hrs         NUMBER(3, 2) NOT NULL,
    academia_id_academia CHAR(5 BYTE) NOT NULL,
    profesor_id_profesor CHAR(5 BYTE) NOT NULL,
    cupo                 NUMBER(2) NOT NULL,
    espacio_id_espacio   CHAR(5 BYTE) NOT NULL
);

ALTER TABLE curso ADD CONSTRAINT curso_pk PRIMARY KEY ( id_curso );

CREATE TABLE director (
    id_director          CHAR(5 BYTE) NOT NULL,
    nombre               VARCHAR2(25 BYTE) NOT NULL,
    segundo_nombre       VARCHAR2(25 BYTE),
    apellido_paterno     VARCHAR2(25 BYTE) NOT NULL,
    apellido_materno     VARCHAR2(25 BYTE),
    rut                  NUMBER(8) NOT NULL,
    digito_verificador   CHAR(1 BYTE) NOT NULL,
    academia_id_academia CHAR(5 BYTE) NOT NULL
);

ALTER TABLE director
    ADD CHECK ( digito_verificador IN ( '0', '1', '2', '3', '4',
                                        '5', '6', '7', '8', '9',
                                        'K' ) );

CREATE UNIQUE INDEX director__idx ON
    director (
        academia_id_academia
    ASC );

ALTER TABLE director ADD CONSTRAINT director_pk PRIMARY KEY ( id_director );

CREATE TABLE espacio (
    id_espacio            CHAR(5 BYTE) NOT NULL,
    municipalidad_id_muni CHAR(5 BYTE) NOT NULL,
    nombre                VARCHAR2(25 BYTE) NOT NULL
);

ALTER TABLE espacio ADD CONSTRAINT espacio_pk PRIMARY KEY ( id_espacio );

CREATE TABLE horario (
    curso_id_curso CHAR(5 BYTE) NOT NULL,
    turno_id_turno CHAR(5 BYTE) NOT NULL,
    horario_inicio DATE NOT NULL,
    horario_fin    DATE NOT NULL
);

ALTER TABLE horario ADD CONSTRAINT horario_pk PRIMARY KEY ( curso_id_curso,
                                                            turno_id_turno );

CREATE TABLE municipalidad (
    id_muni          CHAR(5 BYTE) NOT NULL,
    nombre           VARCHAR2(25 BYTE) NOT NULL,
    comuna_id_comuna CHAR(5 BYTE) NOT NULL
);

CREATE UNIQUE INDEX municipalidad__idx ON
    municipalidad (
        comuna_id_comuna
    ASC );

ALTER TABLE municipalidad ADD CONSTRAINT municipalidad_pk PRIMARY KEY ( id_muni );

CREATE TABLE postulacion (
    academia_id_academia CHAR(5 BYTE) NOT NULL,
    programa_id_programa CHAR(5 BYTE) NOT NULL,
    fecha                DATE NOT NULL,
    cod_postulacion      CHAR(5 BYTE) NOT NULL
);

ALTER TABLE postulacion ADD CONSTRAINT postulacion_pk PRIMARY KEY ( academia_id_academia,
                                                                    programa_id_programa );

CREATE TABLE prof_honorario (
    id_profesor  CHAR(5 BYTE) NOT NULL,
    tarifa_hora  NUMBER(5) NOT NULL,
    cantidad_hrs NUMBER(2) NOT NULL
);

ALTER TABLE prof_honorario ADD CONSTRAINT prof_honorario_pk PRIMARY KEY ( id_profesor );

CREATE TABLE prof_planta (
    id_profesor     CHAR(5 BYTE) NOT NULL,
    sueldo_base     NUMBER(6) NOT NULL,
    dias_vacaciones NUMBER(2) NOT NULL
);

ALTER TABLE prof_planta ADD CONSTRAINT prof_planta_pk PRIMARY KEY ( id_profesor );

CREATE TABLE profesor (
    id_profesor        CHAR(5 BYTE) NOT NULL,
    rut                NUMBER(8) NOT NULL,
    digito_verificador CHAR(1 BYTE) NOT NULL,
    nombre             VARCHAR2(25 BYTE) NOT NULL,
    segundo_nombre     VARCHAR2(25 BYTE),
    apellido_paterno   VARCHAR2(25 BYTE) NOT NULL,
    apellido_materno   VARCHAR2(25 BYTE),
    tipo_profesor      CHAR(1 BYTE) NOT NULL
);

ALTER TABLE profesor
    ADD CONSTRAINT restriccion_rut CHECK ( digito_verificador IN ( '0', '1', '2', '3', '4',
                                                                   '5', '6', '7', '8', '9',
                                                                   'K' ) );

ALTER TABLE profesor
    ADD CONSTRAINT restriccion_profesor CHECK ( tipo_profesor IN ( 'H', 'P' ) );

ALTER TABLE profesor ADD CONSTRAINT profesor_pk PRIMARY KEY ( id_profesor );

ALTER TABLE profesor ADD CONSTRAINT profesor_rut_un UNIQUE ( rut );

CREATE TABLE programa (
    id_programa        CHAR(5 BYTE) NOT NULL,
    monto              NUMBER(8) NOT NULL,
    nombre             VARCHAR2(25 BYTE) NOT NULL,
    limite_postulacion DATE NOT NULL
);

ALTER TABLE programa ADD CONSTRAINT programa_pk PRIMARY KEY ( id_programa );

CREATE TABLE region (
    id_region CHAR(5 BYTE) NOT NULL,
    nombre    VARCHAR2(40 BYTE) NOT NULL
);

ALTER TABLE region ADD CONSTRAINT region_pk PRIMARY KEY ( id_region );

CREATE TABLE turno (
    id_turno   CHAR(5 BYTE) NOT NULL,
    tipo_turno CHAR(1 BYTE) NOT NULL
);

ALTER TABLE turno
    ADD CONSTRAINT restriccion_turno CHECK ( tipo_turno IN ( 'D', 'V' ) );

ALTER TABLE turno ADD CONSTRAINT turno_pk PRIMARY KEY ( id_turno );

ALTER TABLE academia
    ADD CONSTRAINT academia_comuna_fk FOREIGN KEY ( comuna_id_comuna )
        REFERENCES comuna ( id_comuna );

ALTER TABLE academia
    ADD CONSTRAINT academia_director_fk FOREIGN KEY ( director_id_director )
        REFERENCES director ( id_director );

ALTER TABLE comuna
    ADD CONSTRAINT comuna_municipalidad_fk FOREIGN KEY ( municipalidad_id_muni )
        REFERENCES municipalidad ( id_muni );

ALTER TABLE comuna
    ADD CONSTRAINT comuna_region_fk FOREIGN KEY ( region_id_region )
        REFERENCES region ( id_region );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_academia_fk FOREIGN KEY ( academia_id_academia )
        REFERENCES academia ( id_academia );

ALTER TABLE contrato
    ADD CONSTRAINT contrato_profesor_fk FOREIGN KEY ( profesor_id_profesor )
        REFERENCES profesor ( id_profesor );

ALTER TABLE cuenta
    ADD CONSTRAINT cuenta_academia_fk FOREIGN KEY ( academia_id_academia )
        REFERENCES academia ( id_academia );

ALTER TABLE cuenta
    ADD CONSTRAINT cuenta_banco_fk FOREIGN KEY ( banco_id_banco )
        REFERENCES banco ( id_banco );

ALTER TABLE curso
    ADD CONSTRAINT curso_academia_fk FOREIGN KEY ( academia_id_academia )
        REFERENCES academia ( id_academia );

ALTER TABLE curso
    ADD CONSTRAINT curso_espacio_fk FOREIGN KEY ( espacio_id_espacio )
        REFERENCES espacio ( id_espacio );

ALTER TABLE curso
    ADD CONSTRAINT curso_profesor_fk FOREIGN KEY ( profesor_id_profesor )
        REFERENCES profesor ( id_profesor );

ALTER TABLE director
    ADD CONSTRAINT director_academia_fk FOREIGN KEY ( academia_id_academia )
        REFERENCES academia ( id_academia );

ALTER TABLE espacio
    ADD CONSTRAINT espacio_municipalidad_fk FOREIGN KEY ( municipalidad_id_muni )
        REFERENCES municipalidad ( id_muni );

ALTER TABLE horario
    ADD CONSTRAINT horario_curso_fk FOREIGN KEY ( curso_id_curso )
        REFERENCES curso ( id_curso );

ALTER TABLE horario
    ADD CONSTRAINT horario_turno_fk FOREIGN KEY ( turno_id_turno )
        REFERENCES turno ( id_turno );

ALTER TABLE municipalidad
    ADD CONSTRAINT municipalidad_comuna_fk FOREIGN KEY ( comuna_id_comuna )
        REFERENCES comuna ( id_comuna );

ALTER TABLE postulacion
    ADD CONSTRAINT postulacion_academia_fk FOREIGN KEY ( academia_id_academia )
        REFERENCES academia ( id_academia );

ALTER TABLE postulacion
    ADD CONSTRAINT postulacion_programa_fk FOREIGN KEY ( programa_id_programa )
        REFERENCES programa ( id_programa );

ALTER TABLE prof_honorario
    ADD CONSTRAINT prof_honorario_profesor_fk FOREIGN KEY ( id_profesor )
        REFERENCES profesor ( id_profesor );

ALTER TABLE prof_planta
    ADD CONSTRAINT prof_planta_profesor_fk FOREIGN KEY ( id_profesor )
        REFERENCES profesor ( id_profesor );

CREATE OR REPLACE TRIGGER arc_arco_profes_prof_honorario BEFORE
    INSERT OR UPDATE OF id_profesor ON prof_honorario
    FOR EACH ROW
DECLARE
    d CHAR(1 BYTE);
BEGIN
    SELECT
        a.tipo_profesor
    INTO d
    FROM
        profesor a
    WHERE
        a.id_profesor = :new.id_profesor;

    IF ( d IS NULL OR d <> 'H' ) THEN
        raise_application_error(-20223, 'FK PROF_HONORARIO_PROFESOR_FK in Table PROF_HONORARIO violates Arc constraint on Table PROFESOR - discriminator column tipo_profesor doesn''t have value ''H'''
        );
    END IF;

EXCEPTION
    WHEN no_data_found THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/

CREATE OR REPLACE TRIGGER arc_arco_profesor_prof_planta BEFORE
    INSERT OR UPDATE OF id_profesor ON prof_planta
    FOR EACH ROW
DECLARE
    d CHAR(1 BYTE);
BEGIN
    SELECT
        a.tipo_profesor
    INTO d
    FROM
        profesor a
    WHERE
        a.id_profesor = :new.id_profesor;

    IF ( d IS NULL OR d <> 'P' ) THEN
        raise_application_error(-20223, 'FK PROF_PLANTA_PROFESOR_FK in Table PROF_PLANTA violates Arc constraint on Table PROFESOR - discriminator column tipo_profesor doesn''t have value ''P'''
        );
    END IF;

EXCEPTION
    WHEN no_data_found THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/
